import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Employee } from '../models/employee';
import { EmpManagerService } from '../services/emp-manager.service';

@Component({
  selector: 'app-emp-add-edit',
  templateUrl: './emp-add-edit.component.html',
  styleUrls: ['./emp-add-edit.component.css']
})
export class EmpAddEditComponent implements OnInit {
  private emp: Employee;
  public frmEmployee: FormGroup;
  
  @Output() employeeSaveOrCancel = new EventEmitter<boolean>();

  @Input() public set employee(value: Employee) {
    this.emp = value;
    this.frmEmployee.patchValue(this.emp);
    this.frmEmployee.patchValue({ "doj": this.emp.dateOfJoining});
  }
  
  public get employee(): Employee{
    return this.emp;
  }

  constructor(private employeeMgr: EmpManagerService, private formBuilder: FormBuilder) { 
    this.frmEmployee = this.formBuilder.group({
      id: new FormControl(''),
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl(''),
      code: new FormControl(''),
      doj: new FormControl(''),
    });
  }

  ngOnInit(): void {
    
  }

  public saveClick(): void {
    if(this.frmEmployee.value)
    {
      this.employeeMgr.saveEmployee(this.frmEmployee.value).subscribe(result => {
        this.employeeSaveOrCancel.emit(true);
      })
    }
  }

  public cancelClick(): void {
    this.employeeSaveOrCancel.emit(false);
  }

}
