import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export enum NotificationType {
  Error,
  Success,
  Info
}

export class NotificationMessage {
  constructor(public type: NotificationType, public message: string) { }
}

@Injectable({
  providedIn: 'root'
})
export class NotificationManagerService {
  private source = new Subject<NotificationMessage>();
  public received$ = this.source.asObservable();


  constructor() { }

  relay(type: NotificationType, message: string, error?: any): void {
    if (type === NotificationType.Error && error){
      console.error(error);
    }
    
    this.source.next(new NotificationMessage(type, message));
  }
}
