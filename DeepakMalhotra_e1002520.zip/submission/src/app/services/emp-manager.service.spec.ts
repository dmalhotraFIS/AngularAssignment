import { TestBed } from '@angular/core/testing';

import { EmpManagerService } from './emp-manager.service';

describe('EmpManagerService', () => {
  let service: EmpManagerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmpManagerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
