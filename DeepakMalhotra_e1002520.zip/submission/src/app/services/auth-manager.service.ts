import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Identity } from '../models/identity';

@Injectable({
  providedIn: 'root'
})
export class AuthManagerService {
  public userIdentity: Identity = null;
  private loginStatus = new Subject<boolean>();
  public loginStatusChanged$ = this.loginStatus.asObservable();

  constructor() { }

  public validate(username: string, password: string): boolean {
    if (username === password)
    {
      this.userIdentity = new Identity(username, "testing");

      this.loginStatus.next(true);
      return true;
    }

    return false;
  }

  public logout(): void {
    this.userIdentity = null;
    this.loginStatus.next(false);
  }

}
