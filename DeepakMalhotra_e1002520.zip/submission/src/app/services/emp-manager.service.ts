import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee'
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmpManagerService {
  private serviceUrl: string = "http://localhost:3000/Employees/"

  constructor(private http: HttpClient) { }

  public getEmployees() : Observable<Employee[]> {
    return this.http.get<Employee[]>(this.serviceUrl)
    .pipe(
      map((result: Employee[]) => {
        return result.map((item: Employee) => {
          return new Employee(item['id'], item['firstName'], item['lastName'], item['code'], item['doj']);
        })
      })
    );
  }

  public saveEmployee(emp: Employee): Observable<Object> {
    if (emp.id != null && emp.id > 0) {
      return this.http.put(this.serviceUrl + emp.id, emp);
    }
    else {
      return this.http.post(this.serviceUrl, emp);
    }
  }

  public deleteEmployee(emp: Employee): Observable<Object> {
    return this.http.delete(this.serviceUrl + emp.id);
  }
}
