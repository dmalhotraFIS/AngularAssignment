import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthManagerService } from './services/auth-manager.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'EmpPortal';
  public isLoggedIn: boolean = false;

  constructor(private authManager: AuthManagerService, private router: Router) {

  }

ngOnInit(): void {
  this.authManager.loginStatusChanged$.subscribe((value: boolean) => {
    this.isLoggedIn = value;
  })
}

btnLogout(): void {
  this.authManager.logout();
  this.router.navigateByUrl("/login");
}

}
