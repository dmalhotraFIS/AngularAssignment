export class Identity {
    constructor(public displayName: string, public token: string) {
        
    }
}
