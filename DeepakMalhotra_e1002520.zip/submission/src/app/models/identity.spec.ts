import { Identity } from './identity';

describe('Identity', () => {
  it('should create an instance', () => {
    expect(new Identity()).toBeTruthy();
  });
});
