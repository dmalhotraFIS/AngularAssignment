export class Employee {
    constructor(public id?:number, public firstName?: string, public lastName?:string, public code?:string, public dateOfJoining?: Date){
    }

    public get fullName(): string {
        return `${this.firstName} ${this.lastName}`;
    }
}
