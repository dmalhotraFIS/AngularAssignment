import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthManagerService } from '../services/auth-manager.service';
import { NotificationManagerService, NotificationType } from '../services/notification-manager.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public frmLogin: FormGroup;

  constructor(private authManager: AuthManagerService, private router: Router, private notificationManager: NotificationManagerService ) { }

  ngOnInit(): void {
    this.frmLogin = new FormGroup({
      username: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required)
    });
  }

  btnLogin(): void {
console.log(this.frmLogin.value);

    if (this.frmLogin.valid)
    {
      if (this.authManager.validate(this.frmLogin.get("username").value, this.frmLogin.get("password").value))
      {
        this.router.navigateByUrl("/home");
      }
      else
      {
        this.notificationManager.relay(NotificationType.Error, "Invalid username/password specified");
      }
    }
    
    
  }

}
