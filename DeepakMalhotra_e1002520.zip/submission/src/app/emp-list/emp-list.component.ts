import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../models/employee';
import { EmpManagerService } from '../services/emp-manager.service';
import { NotificationManagerService, NotificationType } from '../services/notification-manager.service';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  public currentEmployee: Employee = null;
  public dataSource: Employee[];
  displayedColumns: string[] = ['code', 'name', 'doj', 'action'];

  constructor(private empService: EmpManagerService, private notifyService: NotificationManagerService) { }

  ngOnInit(): void {
    this.loadData();
  }

  public editEmployee(emp: Employee): void {
    this.currentEmployee = emp;
  }

  public addEmployee(): void {
    this.currentEmployee = new Employee();
  }

  public deleteEmployee(emp: Employee): void {
    this.empService.deleteEmployee(emp).subscribe((data) => {
      this.loadData();
    });
  }

  onSaveCancel(isSaved: boolean): void {
    this.currentEmployee = null;
      if (isSaved)
      {
        this.loadData();
      }
  }

  private loadData(): void {
    this.empService.getEmployees().subscribe((data: Employee[]) => {
      this.dataSource = data;
    }, 
    (err) => {
      this.notifyService.relay(NotificationType.Error, "Error getting data", err);
    });
  }

}
