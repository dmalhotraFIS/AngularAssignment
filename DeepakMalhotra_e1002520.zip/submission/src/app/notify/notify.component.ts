import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NotificationManagerService } from '../services/notification-manager.service';

@Component({
  selector: 'app-notify',
  templateUrl: './notify.component.html',
  styleUrls: ['./notify.component.css']
})
export class NotifyComponent implements OnInit {

  constructor(private snackBar: MatSnackBar, private notificationManager: NotificationManagerService) { }

  ngOnInit(): void {
    this.notificationManager.received$.subscribe(msg => {
      this.snackBar.open(msg.message, null, {
        duration: 5 * 1000,
      });
    });
  }

}
